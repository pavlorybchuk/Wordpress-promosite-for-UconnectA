"use strict";

document.addEventListener("DOMContentLoaded", () => {
  const message = document.querySelector("#message_input");
  const close_send_modal = document.querySelector("#cancel_btn");
  const open_send_modal = document.querySelector("#open_send_modal");
  const send_message_modal = document.querySelector(".send-modal");
  const aside_back = document.querySelector("#aside_back");
  const send_message = document.querySelector("#send_btn");

  open_send_modal.addEventListener("click", () => {
    send_message_modal.classList.remove("hide");
    aside_back.classList.remove("hide");
  });

  close_send_modal.addEventListener("click", () => {
    send_message_modal.classList.add("hide");
    aside_back.classList.add("hide");
    message.value = "";
  });

  message.addEventListener("input", () => {
    if (!message.value) {
      send_message.classList.add("btn-disabled");
      send_message.disabled = true;
    } else {
      send_message.classList.remove("btn-disabled");
      send_message.disabled = false;
    }
  });

  const copy_btn = document.querySelector(".title-container > svg");

  copy_btn.addEventListener("click", copy_login);

  send_message.addEventListener("click", async () => {
    try {
      const match = window.location.pathname.match(/driver_profile\/(\d+)\/?$/);
      const response = await fetch(send_message_modal.dataset.sendUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CSRFToken": getCookie("csrftoken"),
        },
        body: JSON.stringify({
          message: message.value,
          driver_to_id: match ? parseInt(match[1]) : 0,
        }),
      });

      const result = await response.json();
      if (result.errors) {
        show_popup(result.errors[Object.keys(result.errors)[0]], true);
      }

      if (result.success) {
        close_send_modal.click();
      }
    } catch (err) {
      console.error("Network or server error:", err);
      show_popup("An unexpected error occurred. Please try again.", true);
    }
  });
});
