"use strict";

document.addEventListener("DOMContentLoaded", () => {
  let current_lang;
  if (!localStorage.getItem("c_lang")) {
    localStorage.setItem("c_lang", "en");
    current_lang = "en";
  } else {
    current_lang = localStorage.getItem("c_lang");
  }

  const car_number_input = document.querySelector("#car_number_input");
  const search_btn = document.querySelector("#search_btn");
  if (car_number_input.value) {
    search_btn.classList.remove("hide");
  }
  car_number_input.addEventListener("input", () => {
    if (car_number_input.value) {
      search_btn.classList.remove("hide");
    } else {
      search_btn.classList.add("hide");
    }
  });

  const start_scan = document.querySelector("#start_scan");
  const qr_reader = document.querySelector("#qr_reader");

  let html5QrCode;
  start_scan.addEventListener("click", () => {
    if ((start_scan.dataset.mode === "1")) {
      qr_reader.classList.remove("hide");
      start_scan.textContent = "Stop";
      start_scan.dataset.mode = "2";
      function onScanSuccess(decodedText, decodedResult) {
        window.location.href = decodedText;
      }

      html5QrCode = new Html5Qrcode("qr_reader");
      html5QrCode
        .start(
          { facingMode: "user" },
          {
            fps: 24,
            qrbox: 250,
          },
          onScanSuccess
        )
        .catch((err) => {
          show_popup("Can't use camera", true);
        });
    } else {
      if (html5QrCode) {
        html5QrCode
          .stop()
          .then(() => {
            qr_reader.classList.add("hide");
            start_scan.textContent = "Scan";
            start_scan.dataset.mode = "1";
          })
          .catch((err) => show_popup("Can't turn off the camera"));
      }
    }
  });
  search_btn.addEventListener("click", async () => {
    try {
      const response = await fetch(
        `${search_btn.dataset.searchUrl}?car_number=${car_number_input.value}`,
        {
          method: "GET",
          headers: {
            Accept: "application/json",
          },
        }
      ).then((response) => {
        if (response.redirected) {
          window.location.href = response.url;
        }
        return response.json();
      });

      const result = await response.json();

      if (result.errors) {
        show_popup(result.errors[Object.keys(result.errors)[0]], true);
      }
    } catch (err) {
      console.error("Network or server error:", err);
      show_popup("An unexpected error occurred. Please try again.", true);
    }
  });
});
