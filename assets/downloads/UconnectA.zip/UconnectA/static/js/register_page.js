"use strict";

document.addEventListener("DOMContentLoaded", () => {
  const phone_prefixes = {
    UA: "+380",
    EN: "+44",
    DE: "+49",
    FR: "+33",
    ES: "+34",
    PL: "+48",
  };
  let current_lang;
  if (!localStorage.getItem("c_lang")) {
    localStorage.setItem("c_lang", "en");
    current_lang = "en";
  } else {
    current_lang = localStorage.getItem("c_lang");
  }

  const form = document.querySelector("#main_form");
  const data = {
    email: form.querySelector("#email_input"),
    phone: [
      form.querySelector("#phone_input"),
      form.querySelector("#phone_prefix_chooser .lang-changer-title")
        .textContent,
    ],
    password: form.querySelector("#password_input"),
    repeat_password: form.querySelector("#password_repeat_input"),
    surname: form.querySelector("#surname_input"),
    d_name: form.querySelector("#name_input"),
  };
  const next_btn = form.querySelector("#next_btn");
  const sub_btn = form.querySelector("#sub_btn");

  const inputs = document.querySelectorAll(
    '.input-field[data-required="true"]'
  );

  inputs.forEach((el) => {
    el.addEventListener("input", () => {
      if (
        !data.email.value ||
        !data.phone[0].value ||
        !data.password.value ||
        !data.repeat_password.value
      ) {
        next_btn.classList.add("btn-disabled");
        next_btn.disabled = true;
      } else {
        next_btn.classList.remove("btn-disabled");
        next_btn.disabled = false;
      }
      if (!data.surname.value || !data.d_name.value) {
        sub_btn.classList.add("btn-disabled");
        sub_btn.disabled = true;
      } else {
        sub_btn.classList.remove("btn-disabled");
        sub_btn.disabled = false;
      }
    });
  });

  next_btn.addEventListener("click", () => {
    if (!(data.password.value == data.repeat_password.value)) {
      console.log("ymova");
      show_popup("Password does not match", true);
      return;
    } else {
      form.firstElementChild.nextElementSibling.classList.add(
        "visually-hidden"
      );
      form.lastElementChild.classList.remove("visually-hidden");
      document.querySelector(".main-title").textContent =
        "How should people address you?";
    }

    function change_go_back(e) {
      e.preventDefault();
      form.firstElementChild.nextElementSibling.classList.remove(
        "visually-hidden"
      );
      form.lastElementChild.classList.add("visually-hidden");
      document.querySelector(".main-title").textContent =
        "Sign up and gain access to all the features of UconnectA!";
      document
        .querySelector(".go-back-icon")
        .removeEventListener("click", change_go_back);
    }
    document
      .querySelector(".go-back-icon")
      .addEventListener("click", change_go_back);
  });

  const phone_prefix_chooser = document.querySelector("#phone_prefix_chooser");
  const countries_prefixes_menu = phone_prefix_chooser.lastElementChild;
  const flag = countries_prefixes_menu
    .querySelector(`[data-lang="${current_lang}"]`)
    .firstElementChild.cloneNode(true);

  phone_prefix_chooser.firstElementChild.innerHTML = "";
  phone_prefix_chooser.firstElementChild.appendChild(flag);
  phone_prefix_chooser.firstElementChild.nextElementSibling.textContent =
    current_lang.toUpperCase();
  countries_prefixes_menu
    .querySelector(`[data-lang="${current_lang}"]`)
    .classList.add("visually-hidden");
  document.querySelector("#phone_prefix_chooser + label > p").textContent =
    phone_prefixes[current_lang.toUpperCase()];

  phone_prefix_chooser.addEventListener("click", (e) => {
    if (countries_prefixes_menu.classList.contains("visually-hidden")) {
      countries_prefixes_menu.classList.remove("visually-hidden");
    } else {
      countries_prefixes_menu.classList.add("visually-hidden");
    }
  });

  const languages =
    countries_prefixes_menu.querySelectorAll(".language-wrapper");
  languages.forEach((el) =>
    el.addEventListener("click", (e) => {
      e.stopImmediatePropagation();
      let new_flag = el.firstElementChild.cloneNode(true);
      phone_prefix_chooser.firstElementChild.innerHTML = "";
      phone_prefix_chooser.firstElementChild.appendChild(new_flag);
      phone_prefix_chooser.firstElementChild.nextElementSibling.textContent =
        el.lastElementChild.textContent;
      languages.forEach((l) => {
        l.classList.contains("visually-hidden")
          ? l.classList.remove("visually-hidden")
          : null;
      });
      el.classList.add("visually-hidden");
      countries_prefixes_menu.classList.add("visually-hidden");
      phone_prefix_chooser.nextElementSibling.firstElementChild.textContent =
        phone_prefixes[el.lastElementChild.textContent];
    })
  );

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    sub_btn.disabled = true;
    sub_btn.classList.add("btn-disabled");

    try {
      const response = await fetch(form.action, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CSRFToken": getCookie("csrftoken"),
        },
        body: JSON.stringify({
          email: data.email.value,
          phone: [
            document.querySelector("#phone_prefix_chooser + label > p").textContent +
              data.phone[0].value,
            data.phone[1],
          ],
          password: data.password.value.trim(),
          repeat_password: data.repeat_password.value.trim(),
          surname: data.surname.value,
          name: data.d_name.value,
          patronymic: document.querySelector("#patronymic_input").value,
          about: document.querySelector("#about_input").value,
        }),
      });

      const result = await response.json();

      if (!response.ok) {
        if (result.errors) {
          if (
            ["email", "phone", "password", "password_repeat"].includes(
              Object.keys(result)[0]
            )
          ) {
            document.querySelector(".go-back-icon").click();
          }
          show_popup(result.errors[Object.keys(result.errors)[0]], true);
        } else if (result.error) {
          console.error(result.error);
          show_popup("An unexpected error occurred. Please try again.", true);
        }
      } else {
        sessionStorage.setItem("show_register_popup", "true")
        window.location.href = form.dataset.mainUrl;
      }
    } catch (err) {
      console.error("Network or server error:", err);
      show_popup("An unexpected error occurred. Please try again.", true);
      sub_btn.disabled = false;
      sub_btn.classList.remove("btn-disabled");
      console.log(result);
    }
    sub_btn.disabled = false;
    sub_btn.classList.remove("btn-disabled");
  });
});
