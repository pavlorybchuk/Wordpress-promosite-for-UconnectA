"use strict";

document.addEventListener("DOMContentLoaded", () => {
  if (sessionStorage.getItem("show_register_popup") === "true") {
    show_popup("You have successfully signed up!");
    sessionStorage.setItem("show_register_popup", "false");
  }
  const urlParams = new URLSearchParams(window.location.search);
  const form = document.querySelector("#main_form");
  const data = {
    email: form.querySelector("#email_input"),
    password: form.querySelector("#password_input"),
  };
  const sub_btn = form.querySelector("#sub_btn");

  const inputs = document.querySelectorAll(
    '.input-field[data-required="true"]'
  );
  inputs.forEach((el) => {
    el.addEventListener("input", () => {
      if (!data.email.value || !data.password.value) {
        sub_btn.classList.add("btn-disabled");
        sub_btn.disabled = true;
      } else {
        sub_btn.classList.remove("btn-disabled");
        sub_btn.disabled = false;
      }
    });
  });

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    sub_btn.disabled = true;
    sub_btn.classList.add("btn-disabled");

    try {
      const response = await fetch(form.action, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CSRFToken": getCookie("csrftoken"),
        },
        body: JSON.stringify({
          email: data.email.value,
          password: data.password.value,
          next: urlParams.get("next") || "/main/"
        }),
      });

      const result = await response.json();

      if (!response.ok) {
        if (result.errors) {
          show_popup(result.errors[Object.keys(result.errors)[0]], true);
        } else if (result.error) {
          console.error(result.error);
          show_popup("An unexpected error occurred. Please try again.", true);
        }
      } else {
        window.location.href = result.redirect;
      }
    } catch (err) {
      console.error("Network or server error:", err);
      show_popup("An unexpected error occurred. Please try again.", true);
      sub_btn.disabled = false;
      sub_btn.classList.remove("btn-disabled");
    }
    sub_btn.disabled = false;
    sub_btn.classList.remove("btn-disabled");
  });
});
