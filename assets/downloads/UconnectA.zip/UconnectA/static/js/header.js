"use strict";

document.addEventListener("DOMContentLoaded", () => {
  let current_lang;
  if (!localStorage.getItem("c_lang")) {
    localStorage.setItem("c_lang", "en");
    current_lang = "en";
  } else {
    current_lang = localStorage.getItem("c_lang");
  }

  const lang_changer = document.querySelector("#lang_changer");
  const languages_menu = lang_changer.lastElementChild;
  const flag = languages_menu
    .querySelector(`[data-lang="${current_lang}"]`)
    .firstElementChild.cloneNode(true);

  lang_changer.firstElementChild.innerHTML = "";
  lang_changer.firstElementChild.appendChild(flag);
  lang_changer.firstElementChild.nextElementSibling.textContent =
    current_lang.toUpperCase();
  languages_menu
    .querySelector(`[data-lang="${current_lang}"]`)
    .classList.add("visually-hidden");

  lang_changer.addEventListener("click", (e) => {
    if (languages_menu.classList.contains("visually-hidden")) {
      languages_menu.classList.remove("visually-hidden");
    } else {
      languages_menu.classList.add("visually-hidden");
    }
  });

  const languages = languages_menu.querySelectorAll(".language-wrapper");
  languages.forEach((el) =>
    el.addEventListener("click", (e) => {
      e.stopImmediatePropagation();
      let new_flag = el.firstElementChild.cloneNode(true);
      lang_changer.firstElementChild.innerHTML = "";
      lang_changer.firstElementChild.appendChild(new_flag);
      lang_changer.firstElementChild.nextElementSibling.textContent =
        el.lastElementChild.textContent.toUpperCase();
      languages.forEach((l) => {
        l.classList.contains("visually-hidden")
          ? l.classList.remove("visually-hidden")
          : 0;
      });
      el.classList.add("visually-hidden");
      languages_menu.classList.add("visually-hidden");
      current_lang = el.lastElementChild.textContent.toLowerCase();
      localStorage.setItem("c_lang", current_lang);
    })
  );

  let lastScroll = 0;
  const header = document.querySelector(".page-header");
  window.addEventListener("scroll", () => {
    const currentScroll = window.pageYOffset;
    if (currentScroll > lastScroll && currentScroll > 50) {
      header.classList.add("hide");
      languages_menu.classList.add("visually-hidden");
    } else {
      header.classList.remove("hide");
    }
    lastScroll = currentScroll;
  });
});
