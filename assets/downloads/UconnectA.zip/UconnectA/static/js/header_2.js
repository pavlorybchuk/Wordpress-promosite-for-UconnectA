"use strict";

document.addEventListener("DOMContentLoaded", () => {
  const aside = document.querySelector("#aside_menu");
  const aside_opener = document.querySelector("#aside_opener");
  const aside_closer = aside.querySelector("#aside_closer");
  const aside_back = document.querySelector("#aside_back");

  aside_opener.addEventListener("click", () => {
    aside.classList.remove("hide");
    aside_back.classList.remove("hide");
  });

  aside_closer.addEventListener("click", () => {
    aside.classList.add("hide");
    aside_back.classList.add("hide");
  });

  aside_back.addEventListener("click", (e) => {
    e.stopImmediatePropagation();
    aside.classList.add("hide");
    aside_back.classList.add("hide");
  });

  const aside_tabs = aside.querySelectorAll(".aside-tab");
  aside_tabs.forEach((el) => {
    el.addEventListener("click", (e) => {
      e.stopImmediatePropagation();
      el.lastElementChild.click();
    });
  });

  let lastScroll = 0;
  const header = document.querySelector(".page-header");
  window.addEventListener("scroll", () => {
    const currentScroll = window.pageYOffset;
    if (currentScroll > lastScroll && currentScroll > 50) {
      header.classList.add("hide");
      languages_menu.classList.add("visually-hidden");
    } else {
      header.classList.remove("hide");
    }
    lastScroll = currentScroll;
  });
});
