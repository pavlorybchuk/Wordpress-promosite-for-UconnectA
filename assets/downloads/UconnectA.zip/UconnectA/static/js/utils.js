"use strict";

function getCookie(name) {
  let cookieValue = null;
  if (document.cookie && document.cookie !== "") {
    const cookies = document.cookie.split(";");
    for (let cookie of cookies) {
      cookie = cookie.trim();
      if (cookie.startsWith(name + "=")) {
        cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
        break;
      }
    }
  }
  return cookieValue;
}

let popup_timeout;
function show_popup(popup_text, is_bad = false) {
  const popup_message = document.querySelector("#popup_message");
  if (popup_timeout) {
    popup_message.classList.add("hide");
    clearTimeout(popup_timeout);
    popup_timeout = 0;
  }
  popup_message.firstElementChild.textContent = popup_text;
  if (is_bad) {
    popup_message.style.setProperty("--border-col", "var(--color-bad)");
  } else {
    popup_message.style.setProperty("--border-col", "var(--color-good)");
  }
  popup_message.classList.remove("hide");
  popup_timeout = setTimeout(() => {
    popup_message.classList.add("hide");
  }, 4000);
}

let copy_timeout;
function copy_login() {
  const login = document.querySelector(".username").textContent;
  const title_copied = document.querySelector(".copied-message");
  if (popup_timeout) {
    title_copied.classList.remove("copied");
    clearTimeout(copy_timeout);
    copy_timeout = 0;
  }
  navigator.clipboard
    .writeText(login)
    .then(() => {
      title_copied.textContent = "Copied!"
      title_copied.classList.add("copied");
      copy_timeout = setTimeout(() => {
        title_copied.classList.remove("copied");
      }, 3000);
    })
    .catch((err) => {
      title_copied.innerHTML = "Can't copy<br>username"
      title_copied.classList.add("copied");
      copy_timeout = setTimeout(() => {
        title_copied.classList.remove("copied");
      }, 3000);
    });
}
