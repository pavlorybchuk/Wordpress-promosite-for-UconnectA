from django.contrib import admin
from .models import Driver, Car, Driver_rate

admin.site.register(Driver)
admin.site.register(Car)
admin.site.register(Driver_rate)