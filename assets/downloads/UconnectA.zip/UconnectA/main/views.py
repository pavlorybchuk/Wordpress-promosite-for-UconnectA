from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from django.core.mail import send_mail
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST, require_GET
from django.views.decorators.csrf import csrf_protect
from email_validator import validate_email, EmailNotValidError
from django.conf import settings
import phonenumbers
import json
import re
from io import BytesIO
from django.core.files import File
import qrcode
from .models import Driver, Driver_rate, Car
import uuid

def welcome_page(request):
    return render(request, "main/welcome_page.html")

def register_page(request):
    return render(request, "main/register_page.html")

def login_page(request):
    next_url = request.GET.get('next', '/main/')
    return render(request, "main/login_page.html", {'next': next_url})

@require_POST
@csrf_protect
def login_user(request):
    try:
        data = json.loads(request.body.decode("utf-8"))
    except json.JSONDecodeError:
        return JsonResponse({"error": "Invalid JSON format"}, status=400)

    email = data.get("email", "").strip()
    password = data.get("password", "").strip()
    next_url = data.get("next", "/main/")

    user = authenticate(request, username=email, password=password)
    if user is not None:
        login(request, user)
        next_url = request.GET.get("next", "/main/")
        return JsonResponse({"success": True, "redirect": next_url}, status=200)
    else:
        return JsonResponse({"errors": {"login": "Invalid email or password"}}, status=400)

@login_required(login_url="/login/")
def main_page(request):
    return render(request, "main/main_page.html")

@require_GET
@login_required(login_url="/login/")
def search_driver(request):
    car_number = request.GET.get("car_number", "").strip().upper()
    car = Car.objects.filter(car_number=car_number).first()
    if car:
        return redirect("driver_profile", driver_id=car.driver.id)
    else:
        return JsonResponse({'errors': {"no-driver": "There is no driver with this number"}})

@login_required(login_url="/login/")
def driver_profile(request, driver_id):
    driver = get_object_or_404(Driver, id=driver_id)
    return render(request, "main/driver_profile_page.html", {"driver": driver})

@login_required(login_url="/login/")
def profile_page(request):
    return render(request, "main/profile_page.html")

@login_required(login_url="/login/")
def change_profile(request):
    return render(request, "main/change_profile_page.html")

@require_POST
@csrf_protect
def register_user(request):
    try:
        data = json.loads(request.body.decode("utf-8"))
    except json.JSONDecodeError:
        return JsonResponse({"error": "Invalid JSON format"}, status=400)

    email = data.get("email", "").strip()
    password = data.get("password", "").strip()
    password_repeat = data.get("repeat_password", "").strip()
    name = data.get("name", "").strip()
    surname = data.get("surname", "").strip()
    patronymic = data.get("patronymic", "").strip()
    phone = data.get("phone", "")
    about = data.get("about", "").strip()

    errors = {}

    try:
        validate_email(email)
        if User.objects.filter(email=email).exists():
            errors["email"] = "This email is already used"
    except EmailNotValidError:
        errors["email"] = "Invalid email"

    try:
        parsed_phone = phonenumbers.parse(phone[0], phone[1])
        if not phonenumbers.is_valid_number(parsed_phone):
            errors["phone"] = "Invalid phone number"
        elif Driver.objects.filter(phonenumber=phone[0]).exists():
            errors["phone"] = "This phone number is already used"
    except:
        errors["phone"] = "Invalid phone number"
    
    if 6 <= len(password) <= 16:
        if password != password_repeat:
            errors["password"] = "Passwords do not match"
    else:
        errors["password"] = "Password can consist only 6-16 characters"

    if errors:
        return JsonResponse({"errors": errors}, status=400)

    user = User.objects.create_user(
        username=email,
        email=email,
        password=password,
        first_name=name,
        last_name=surname
    )

    Driver.objects.create(
        user=user,
        login=generate_login(),
        phonenumber=phone[0],
        about_driver=about if about else None,
        photo=None,
        patronymic=patronymic
    )

    return JsonResponse({"success": True}, status=200)


@login_required
@csrf_protect
@require_POST
def send_email(request):
    try:
        data = json.loads(request.body.decode("utf-8"))
    except json.JSONDecodeError:
        return JsonResponse({"error": "Invalid JSON format"}, status=400)
    message = data.get('message')
    driver_to_id = data.get('driver_to_id')
    driver_from = Driver.objects.get(user=request.user)
    print(driver_from, driver_to_id)

    try:
        driver_to = Driver.objects.get(id=driver_to_id)
    except Driver.DoesNotExist:
        return JsonResponse({'status': 'Driver not found'}, status=404)
    
    if not message:
        return JsonResponse({"errors": {'message': 'Message cannot be empty'}})
    
    send_mail(
        subject=f"New message from {driver_from.login}",
        message=message,
        from_email=settings.EMAIL_HOST_USER,
        recipient_list=[driver_to.user.email],
        fail_silently=False,
    )

    return JsonResponse({'success': True}, status=200)

def generate_login() -> str:
    try:
        last_driver = Driver.objects.latest('id')
        last_id = last_driver.id
    except Driver.DoesNotExist:
        last_id = 0
        
    return f"user{last_id + 1}"

def generate_driver_qr(driver):
    qr_url = f"http://127.0.0.1:8000/driver_profile/{driver.id}/"
    qr = qrcode.make(qr_url)

    buffer = BytesIO()
    qr.save(buffer, format='PNG')
    filename = f"{uuid.uuid4().hex}.png"

    driver.qr_code.save(filename, File(buffer), save=False)
    driver.save(update_fields=['qr_code'])