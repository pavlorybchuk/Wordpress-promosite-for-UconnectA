from django.contrib.auth.models import User
from django.db import models as m
from phonenumber_field.modelfields import PhoneNumberField
import uuid
from django.core.files import File
from io import BytesIO
import qrcode


def avatar_upload_path(instance, filename):
    ext = filename.split('.')[-1]
    unique_name = uuid.uuid4().hex
    return f'avatars/{unique_name}.{ext}'

class Driver(m.Model):
    user = m.OneToOneField(User, on_delete=m.CASCADE, related_name="driver_profile")
    id = m.AutoField(primary_key=True)
    login = m.CharField(max_length=50, unique=True, db_collation="utf8mb4_bin")
    patronymic = m.CharField(max_length=30, null=True, blank=True)
    phonenumber = PhoneNumberField(max_length=25)
    photo = m.ImageField(upload_to=avatar_upload_path, null=True, blank=True)
    qr_code = m.ImageField(upload_to='qr_codes/', blank=True, null=True)
    about_driver = m.CharField(max_length=600, null=True, blank=True)

    def __str__(self):
        return f"{self.login}"
    
    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)

        if not self.qr_code:
            qr_url = f"http://127.0.0.1:8000/driver_profile/{self.id}/"
            qr = qrcode.make(qr_url)
            buffer = BytesIO()
            qr.save(buffer, format='PNG')
            filename = f"driver_{self.id}.png"
            self.qr_code.save(filename, File(buffer), save=False)
            super().save(update_fields=['qr_code'])
    
class Car(m.Model):
    car_number = m.CharField(max_length=8, unique=True, primary_key=True, db_collation="utf8mb4_bin")
    driver = m.ForeignKey(Driver, on_delete=m.CASCADE)

    def __str__(self):
        return f"{self.driver.login} - {self.car_number}"

class Driver_rate(m.Model):
    rate_id = m.BigIntegerField(unique=True, primary_key=True)
    rate = m.DecimalField(max_digits=2, decimal_places=1)
    sender = m.ForeignKey(Driver, on_delete=m.CASCADE, related_name="sent_rates")
    adresse = m.ForeignKey(Driver, on_delete=m.CASCADE, related_name="received_rates")

    def __str__(self):
        return f"{self.adresse.login} - {self.rate}"
